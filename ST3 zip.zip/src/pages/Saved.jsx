const Saved = () => {
  return <div style={{marginLeft:'50px'}}className="title"> Saved</div>;
};

export default Saved;
