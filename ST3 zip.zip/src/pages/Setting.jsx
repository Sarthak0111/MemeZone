const Setting = () => {
  return <div style={{marginLeft:'50px'}} className="title"> Setting</div>;
};

export default Setting;
