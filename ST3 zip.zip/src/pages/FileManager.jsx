const FileManager = () => {
  return <div style={{marginLeft:'50px'}}className="title"> File Manager</div>;
};

export default FileManager;
