const Order = () => {
  return <div style={{marginLeft:'50px'}}className="title"> Order</div>;
};

export default Order;
