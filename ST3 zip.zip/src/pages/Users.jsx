const Users = () => {
  return <div style={{marginLeft:'50px'}} className="title"> Users</div>;
};

export default Users;
