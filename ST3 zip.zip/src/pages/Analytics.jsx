const Analytics = () => {
  return <div style={{marginLeft:'50px'}} className="title"> Analytics</div>;
};

export default Analytics;
