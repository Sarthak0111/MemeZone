const Messages = () => {
  return <div style={{marginLeft:'50px'}}className="title"> Messages</div>;
};

export default Messages;
